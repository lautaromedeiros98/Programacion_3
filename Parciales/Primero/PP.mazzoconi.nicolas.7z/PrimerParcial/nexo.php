<?php
$tipo = $_SERVER['REQUEST_METHOD'];

switch ($tipo) {
    case 'GET':
        switch ($_GET["caso"])
        {
            case 'consultarVehiculo':
                require_once "./Funciones/consultarVehiculo.php";
                break;
            
            case 'sacarTurno':
                require_once "./Funciones/sacarTurno.php";
                break;

            case 'turnos':
                require_once "./Funciones/turnos.php";
                break;
            
            case 'inscripciones':
                require_once "./Funciones/inscripciones.php";
                break;

            case 'vehiculos':
                require_once "./Funciones/vehiculos.php";
                break;
        }
        break;
    
    case 'POST':
        switch ($_POST["caso"])
        {
            case 'cargarVehiculo':
                require_once "./Funciones/cargarVehiculo.php";
                break;
            
            case 'cargarTipoServicio':
                require_once "./Funciones/cargarTipoServicio.php";
                break;

            case 'modificarVehiculo':
                require_once "./Funciones/modificarVehiculo.php";
                break;
        }
        break;
}
?>
<?php
include_once "./Clases/Vehiculo.php";
include_once "./Clases/Servicio.php";

if(isset($_GET["fecha"]) && isset($_GET["patente"]) && isset($_GET["id"]))
{
    $auto = Vehiculo::existeEsteAutoPorPatente($_GET["patente"], "./Archivos/vehiculos.txt");
    $servicio = Servicio::existeEsteServicioPorId($_GET["id"], "./Archivos/tiposServicio.txt");
    if($auto != null && $servicio != null)
    {
        $archivo = "./Archivos/turnos.txt";
        $fecha = $_GET["fecha"];
        $patente = $auto["patente"];
        $marca = $auto["marca"];
        $modelo = $auto["modelo"];
        $precio = $servicio["precio"];
        $tipo = $servicio["precio"];

        $actual = "Fecha: $fecha, Patente: $patente, Marca: $marca, Modelo: $modelo, Precio: $precio, Tipo: $tipo";
        
        if(file_exists($archivo))
        {
            $archivo = fopen($archivo, "a");		 
        }else
        {
            $archivo = fopen($archivo, "w");	 
        }
        
        $renglon = $actual.="\r\n";
        
        fwrite($archivo, $renglon); 		 
        fclose($archivo);
    }
}
?>
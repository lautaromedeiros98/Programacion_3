<?php
include_once "./Clases/Vehiculo.php";

$datos = Vehiculo::leerArchivo("./Archivos/vehiculos.txt");
$flag = 0;
$flagBusqueda;
$marca;
$modelo;
$patente;
$precio;
if($datos != false)
{
    foreach($datos as $value)
    {
        if(isset($_GET["buscar"]))
        {
            $flag = 1;
            $flagBusqueda = $_GET["buscar"];
            if(strcasecmp($_GET["buscar"], $value["marca"]) == 0 || strcasecmp($_GET["buscar"], $value["patente"]) == 0 || strcasecmp($_GET["buscar"], $value["modelo"]) == 0)
            {
                $marca = $value["marca"];
                $modelo = $value["modelo"];
                $patente = $value["patente"];
                $precio = $value["precio"];
                echo "Marca: $marca, Modelo: $modelo, Patente: $patente, Precio: $precio";
            }
        }
    }
}

if($flag == 0)
{
    echo "No se encontro $flagBusqueda";
}
?>
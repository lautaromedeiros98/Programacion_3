<?php

$archivo = "./Archivos/turnos.txt";
if(file_exists($archivo))
{
    $gestor = @fopen($archivo, "r");
    if(isset($_GET["buscar"]))
    {
        $fecha = $_GET["buscar"];
        $fecha.= ",";
        $tipo = $_GET["buscar"];
        $tipo.= "\r\n";
        while (($bufer = fgets($gestor, 4096)) !== false)
        {   
            $datos = explode(" ", $bufer);
            if($datos[1] == $fecha || $datos[11] == $tipo) 
            {
                var_dump($datos[1]);
                echo "$bufer";
                echo "<br>";
            }
        }
        
        if (!feof($gestor)) 
        {
                echo "Error: fallo inesperado de fgets()\n";
        }	
    }
    fclose($gestor);
}   


?>
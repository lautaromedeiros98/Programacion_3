<?php
include_once "./Clases/Vehiculo.php";

if(isset($_POST["marca"]) && isset($_POST["modelo"]) && isset($_POST["patente"]) && isset($_POST["precio"]))
{
    $miClase = new Vehiculo();
    $miClase -> miConstructor($_POST["marca"], $_POST["modelo"], $_POST["patente"], $_POST["precio"]);
    if($miClase -> verificarPatente("./Archivos/vehiculos.txt"))
        $miClase -> guardarArchivo("./Archivos/vehiculos.txt");
    else
    {
        echo "La patente ya existe";
    }
}


?>
<?php

function guardarFoto($file, $post = null, $patente = null, $fecha = null)
{
    $dic = "./Fotos/";
    $dicBackup = "./backUpFotos/";
    $nameImagen = $file["foto"]["name"];
    
	if(isset($post["patente"]))
	{
		$datoImagen = $post["patente"]."-".$fecha;
	}	
	elseif($patente != null && $fecha != null)
	{
		$datoImagen = $patente."-".$fecha;
    }
    else{
        $datoImagen = "sinDatos";
    }
    
	$explode = explode(".", $nameImagen);
	$tamaño = count($explode);

	$dic .= $datoImagen;
	$dic .= ".";
	$dic .= $explode[$tamaño - 1];

    $hoy = date("m.d.y");
    $dicBackup .= $post["patente"];
	$dicBackup .= "-".$hoy;
	$dicBackup .= ".";
	$dicBackup .= $explode[$tamaño - 1];

	if(!file_exists($dic))
	{
        
        move_uploaded_file($_FILES["foto"]["tmp_name"], $dic);		
	}
	else
	{
        copy($dic, $dicBackup);
		move_uploaded_file($_FILES["foto"]["tmp_name"], $dic);
	}
    
    return $dic;
}


?>
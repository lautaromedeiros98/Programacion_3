<?php
$archivo = "./Archivos/turnos.txt";
if(file_exists($archivo))
{
    $gestor = @fopen($archivo, "r");
    while (($bufer = fgets($gestor, 4096)) !== false)
    {
        echo "$bufer";
        echo "<br>";
    }
       
       if (!feof($gestor)) 
    {
            echo "Error: fallo inesperado de fgets()\n";
    }		
    fclose($gestor);
}   



?>
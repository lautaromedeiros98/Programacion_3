<?php
include_once "./Clases/Servicio.php";

if(isset($_POST["nombre"]) && isset($_POST["id"]) && isset($_POST["tipo"]) && isset($_POST["precio"]) && isset($_POST["demora"]))
{
    $miClase = new Servicio();
    $miClase -> miConstructor($_POST["nombre"], $_POST["id"], $_POST["tipo"], $_POST["precio"], $_POST["demora"]);
    if($miClase -> verificarTipo())
        $miClase -> guardarArchivo("./Archivos/tiposServicio.txt");
    else
    {
        echo "Tipo invalido";
    }
}

?>
<?php
include_once "./Clases/Vehiculo.php";

$datos = Vehiculo::leerArchivo("./Archivos/vehiculos.txt");

if($datos != false)
{
    foreach($datos as $value)
    {
        $marca = $value["marca"];
        $modelo = $value["modelo"];
        $patente = $value["patente"];
        $precio = $value["precio"];
        $foto = $value["foto"];
        echo "Marca: $marca, Modelo: $modelo, Patente: $patente, Precio: $precio"; 
        echo "<br>";
        if($foto != null)
        {
            echo "<img src='$foto' border='0' width='300' height='100'>"; 
        }
        echo "<br>";
            
    }
}


?>
<?php
include_once "./Clases/Vehiculo.php";
include_once "./Funciones/agregarFoto.php";

if(isset($_POST["patente"]))
{
    $patente = isset($_POST["patente"])?$_POST["patente"]:null;
    $modelo = isset($_POST["modelo"])?$_POST["modelo"]:null;
    $marca = isset($_POST["marca"])?$_POST["marca"]:null;
    $precio = isset($_POST["precio"])?$_POST["precio"]:null;
    $foto = isset($_FILES["foto"])?true:null;


    $arrayMiClase = Vehiculo::leerArchivo("./Archivos/vehiculos.txt");
    $i = 0;
    foreach($arrayMiClase as $value)
    {
      
        if($value["patente"] == $patente)
        {
            if($modelo == null)
                $modelo = $value["modelo"];
            if($marca == null)
                $marca = $value["marca"];
            if($precio == null)
                $precio = $value["precio"];
            if($foto == true)
            {
                $fecha = date("m.d.y");
                $foto = guardarFoto($_FILES, $_POST, $patente, $fecha);
                $newClass = new Vehiculo();
                $newClass -> miConstructor($marca, $modelo, $patente, $precio);
                $arrayMiClase[$i] = $newClass;
                $newClass -> cargarFoto($foto);
                break;
            }
            else
            {
                $newClass = new Vehiculo();
                $newClass -> miConstructor($marca, $modelo, $patente, $precio);
                $arrayMiClase[$i] = $newClass;
                break;
            }
        }
        $i++;
    }
    Vehiculo::guardarArray($arrayMiClase, "./Archivos/vehiculos.txt");
}





?>
<?php
class Vehiculo
{
    public $marca;
    public $modelo;
    public $patente;
    public $precio;
    public $foto;

    public function miConstructor($marca, $modelo, $patente, $precio)
    {
        $this -> marca = $marca;
        $this -> modelo = $modelo;
        $this -> patente = $patente;
        $this -> precio = $precio;
        $this -> foto = null;
    }

    public function retornarJSon()
    {
        return json_encode($this);
    }

    public function guardarArchivo($path)
    {
        if($path != null)
        {
            $archivo = $path;
            $actual = $this -> retornarJSon();
            
            if(file_exists($archivo))
            {
                $archivo = fopen($path, "a");		 
            }else
            {
                $archivo = fopen($path, "w");	 
            }
            
            $renglon = $actual.="\r\n";
            
            fwrite($archivo, $renglon); 		 
            fclose($archivo);
        }
    }

    public static function leerArchivo($path)
    {
        $archivo = $path;
		if(file_exists($archivo))
		{
			$gestor = @fopen($archivo, "r");
			$arrayProveedores = array();
			$i = 0;
			while (($bufer = fgets($gestor, 4096)) !== false)
        	{
                $miClase = new Vehiculo();
                $miClase = json_decode($bufer, true);
        		$arrayProveedores[$i] = $miClase;
        		$i++;
           	}
           	
           	if (!feof($gestor)) 
    		{
       	 		echo "Error: fallo inesperado de fgets()\n";
            }		
            	
    		fclose($gestor);
    		return $arrayProveedores;
        }   
        return false;	
    }

    public static function guardarArray($array, $path)
    {
        $archivo=fopen($path, "w"); 	
		foreach ($array as $value) 
		{
            $dato= json_encode($value);
	 		$dato.="\r\n";
			fwrite($archivo, $dato);
		}
        fclose($archivo);
    }

    public function verificarPatente($path)
    {
        $datos = Vehiculo::leerArchivo($path);
        if($datos != false)
        {
            foreach($datos as $value)
            {
                if($value["patente"] == $this -> patente)
                    return false;
            }
        }
        return true;
    }

    public static function existeEsteAutoPorPatente($patente, $path)
    {
        $datos = Vehiculo::leerArchivo($path);
        if($datos != false)
        {
            foreach($datos as $value)
            {
                if($value["patente"] == $patente)
                    return $value;
            }
        }
        return null;
    }

    public function cargarFoto($foto)
    {
        $this -> foto = $foto;
    }
}


?>
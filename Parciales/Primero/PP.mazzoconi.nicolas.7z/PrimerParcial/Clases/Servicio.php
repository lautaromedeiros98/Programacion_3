<?php
class Servicio
{
    public $nombre;
    public $id;
    public $tipo;
    public $precio;
    public $demora;

    public function miConstructor($nombre, $id, $tipo, $precio, $demora)
    {
        $this -> nombre = $nombre;
        $this -> id = $id;
        $this -> tipo = $tipo;
        $this -> precio = $precio;
        $this -> demora = $demora;
    }

    public function retornarJSon()
    {
        return json_encode($this);
    }

    public function guardarArchivo($path)
    {
        if($path != null)
        {
            $archivo = $path;
            $actual = $this -> retornarJSon();
            
            if(file_exists($archivo))
            {
                $archivo = fopen($path, "a");		 
            }else
            {
                $archivo = fopen($path, "w");	 
            }
            
            $renglon = $actual.="\r\n";
            
            fwrite($archivo, $renglon); 		 
            fclose($archivo);
        }
    }

    public static function leerArchivo($path)
    {
        $archivo = $path;
		if(file_exists($archivo))
		{
			$gestor = @fopen($archivo, "r");
			$arrayProveedores = array();
			$i = 0;
			while (($bufer = fgets($gestor, 4096)) !== false)
        	{
                $miClase = new Servicio();
                $miClase = json_decode($bufer, true);
        		$arrayProveedores[$i] = $miClase;
        		$i++;
           	}
           	
           	if (!feof($gestor)) 
    		{
       	 		echo "Error: fallo inesperado de fgets()\n";
            }		
            	
    		fclose($gestor);
    		return $arrayProveedores;
        }   
        return false;	
    }

    public static function guardarArray($array, $path)
    {
        $archivo=fopen($path, "w"); 	
		foreach ($array as $value) 
		{
            $dato= json_encode($value);
	 		$dato.="\r\n";
			fwrite($archivo, $dato);
		}
        fclose($archivo);
    }

    public function verificarTipo()
    {
        switch($this -> tipo)
        {
            case '10000':
                return true;
            case '20000':
                return true;
            case '50000':
                return true;
            default:
                return false;
        }
    }

    public static function existeEsteServicioPorId($id, $path)
    {
        $datos = Servicio::leerArchivo($path);
        if($datos != false)
        {
            foreach($datos as $value)
            {
                if($value["id"] == $id)
                    return $value;
            }
        }
        return null;
    }
}


?>